# Only for backwards compatibility.
from .mobilenet_v2 import *
